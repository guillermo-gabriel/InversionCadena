package invertirCadena;

public class InversionCadena {

	public static void main(String[] args) {
		
		Cadenax n1 = new Cadenax();
		System.out.println("el la palabra imvertida es: "+ n1.invertir("hola"));

	}
	

}
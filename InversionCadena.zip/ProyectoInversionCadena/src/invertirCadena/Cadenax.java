package invertirCadena;

public class Cadenax {
	
	
	public String invertir(String cadena) {
		String cadenaInvertida ="";
		         //hola  . 5     
		for (int i=cadena.length()-1;i>=0; i--)
			cadenaInvertida = cadenaInvertida + cadena.charAt(i);
		return cadenaInvertida;
		
	}

}
